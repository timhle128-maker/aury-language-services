const menu = document.querySelector('.menu');
const nav = document.getElementById('primary-nav');
menu?.addEventListener('click', () => {
 const open = nav.classList.toggle('open');
 menu.setAttribute('aria-expanded', String(open));
});
nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
 nav.classList.remove('open');
 menu?.setAttribute('aria-expanded', 'false');
}));
